#include<stdio.h>

int main()
{
    int i,j,temp1=1,temp2=1,det;
    int mat[2][2];
    printf("Enter the elements of the matrix: ");
    for(i=0;i<2;i++)
    {
        for(j=0;j<2;j++)
        {
            scanf("%d",&mat[i][j]);
        }
    }
    for(i=0;i<2;i++)
    {
        temp1*=mat[i][i];
        for(j=0;j<2;j++)
        {
            if(i!=j)
               temp2*=mat[i][j];
        }
    }
    det=temp1-temp2;
    printf("The determinant of the matrix is %d",det);

    return 0;
}
