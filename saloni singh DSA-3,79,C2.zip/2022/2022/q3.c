#include<stdio.h>

int main()
{
    int mat1[4][5],mat2[4][5],mat3[4][5];
    int i,j;
    printf("Enter the elements of 1st 4x5 matrix: ");
    for(i=0;i<4;i++)
    {
        for(j=0;j<5;j++)
            {
                scanf("%d",&mat1[i][j]);
            }
    }

    printf("Enter the elements of 2nd 4x5 matrix: ");
    for(i=0;i<4;i++)
    {
        for(j=0;j<5;j++)
            {
                scanf("%d",&mat2[i][j]);
            }
    }

    for(i=0;i<4;i++)
    {
        for(j=0;j<5;j++)
            {
                mat3[i][j]=mat1[i][j]-mat2[i][j];
            }
    }

    printf("Enter the resultant matrix is: \n");
    for (i=0;i<4;i++)
    {
        for (j=0;j<5;j++)
            {
                printf("%d  ",mat3[i][j]);
            }
        printf("\n");
    }
    return 0;
}
