#include<stdio.h>

int main()
{
    int m,n,i,j,sum;
    printf("Enter the dimensions of the matrix: ");
    scanf("%d,%d",&m,&n);
    int mat[m][n];
    printf("Enter the elements of the matrix: ");
    for(i=0;i<m;i++)
    {
        for(j=0;j<n;j++)
        {
            scanf("%d",&mat[i][j]);
        }
    }

    for(i=0;i<m;i++)
    {
        for(j=0;j<n;j++)
        {
           sum+=mat[i][j];
        }
    }

    printf("The sum of the elements of the matrix is %d",sum);

    return 0;
}
