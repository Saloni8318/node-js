#include<stdio.h>

int main()
{
    int m,n,i,j,scalar;
    printf("Enter the dimensions of the matrix: ");
    scanf("%d,%d",&m,&n);
    printf("Enter the scalar: ");
    scanf("%d",&scalar);
    int mat[m][n];
    printf("Enter the elements of the matrix: ");
    for(i=0;i<m;i++)
    {
        for(j=0;j<n;j++)
        {
            scanf("%d",&mat[i][j]);
        }
    }

    for(i=0;i<m;i++)
    {
        for(j=0;j<n;j++)
        {
           mat[i][j]*=scalar;

        }
    }

    printf("The resultant matrix is: \n");
    for(i=0;i<m;i++)
    {
        for(j=0;j<n;j++)
        {
            printf("%d  ",mat[i][j]);
        }
        printf("\n");
    }
    return 0;
}
