#include<stdio.h>

int main()
{
    int mat1[3][4],mat2[4][3],mat3[3][3];
    int i,j,k,s;
    printf("Enter the elements of the 3x4 matrix: ");
    for (i=0;i<3;i++)
    {
        for (j=0;j<4;j++)
            {
                scanf("%d",&mat1[i][j]);
            }
     }

    printf("Enter the elements of the 4x3 matrix: ");
    for(i=0;i<4; i++)
    {
        for(j=0;j<3; j++)
            {
                scanf("%d",&mat2[i][j]);
            }
    }

    for(i=0;i<3;i++)
    {
        for(j=0;j<3;j++)
            {
                s=0;
                for(k=0;k<4;k++)
                    {
                        s+=mat1[i][k]*mat2[k][j];
                    }
            mat3[i][j]=s;
            }
     }

    printf("The resultant 3x3 matrix is: \n");
    for(i=0;i<3;i++)
    {
        for(j=0;j<3;j++)
            {
                printf("%d  ",mat3[i][j]);
            }
            printf("\n");
     }
     return 0;
}

