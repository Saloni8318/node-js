#include<stdio.h>

int main()
{
    int m,n,p,q,i,j,temp=0;
    printf("Enter the dimensions of the 1st matrix: ");
    scanf("%d,%d",&m,&n);
    printf("Enter the dimensions of the 2nd matrix: ");
    scanf("%d,%d",&p,&q);
    int mat1[m][n],mat2[p][q];
    if((m!=p) || (n!=q) || (m!=p && n!=q))
    {
        printf("The matrices are not equal");
    }
    else
    {
        printf("Enter the elements of the 1st matrix: ");
        for(i=0;i<m;i++)
        {
            for(j=0;j<n;j++)
                {
                    scanf("%d",&mat1[i][j]);
                }
        }

        printf("Enter the elements of the 2nd matrix: ");
        for(i=0;i<p;i++)
        {
            for(j=0;j<q;j++)
                {
                    scanf("%d",&mat2[i][j]);
                }
        }

        for(i=0;i<m;i++)
        {
            for(j=0;j<n;j++)
            {
                if(mat1[i][j]!=mat2[i][j])
                {
                    temp++;
                    break;
                }
            }
        }
    if(temp!=0)
        printf("The matrices are not equal");
    else
        printf("The matrices are equal");
    }
    return 0;
}
