#include<stdio.h>

int main()
{
    int m,n,i,j;
    printf("Enter the dimensions of the matrix: ");
    scanf("%d,%d",&m,&n);
    int mat[m][n];

    if(m!=n)
    {
        printf("Diagonal elements don't exist");
    }

    else
    {
        printf("Enter the elements of the matrix: ");
        for(i=0;i<m;i++)
        {
            for(j=0;j<n;j++)
                {
                    scanf("%d",&mat[i][j]);
                }
        }

        printf("The diagonal elements of the matrix are: \n");
        for(i=0;i<m;i++)
        {
             printf("%d  ",mat[i][i]);
        }
    }
    return 0;
}
