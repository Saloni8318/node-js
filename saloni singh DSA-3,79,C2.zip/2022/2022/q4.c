#include<stdio.h>

int main()
{
    int m,n,i,j,temp=0;
    printf("Enter the dimensions of the matrix: ");
    scanf("%d,%d",&m,&n);
    int mat[m][n];

    if(m!=n)
    {
        printf("Only a square matrix can be a symmetric matrix");
    }

    else
    {
        printf("Enter the elements of the matrix: ");
        for(i=0;i<m;i++)
        {
            for(j=0;j<n;j++)
                {
                    scanf("%d",&mat[i][j]);
                }
        }

        for(i=0;i<m;i++)
        {
            for(j=0;j<n;j++)
                {
                    if(i!=j)
                    {
                        if(mat[i][j]!=mat[j][i])
                        {
                            temp++;
                            break;
                        }
                    }
                }
        }

        if(temp!=0)
            printf("The matrix is not a symmetric matrix");
        else
             printf("The matrix is symmetric matrix");
    }
    return 0;
}
